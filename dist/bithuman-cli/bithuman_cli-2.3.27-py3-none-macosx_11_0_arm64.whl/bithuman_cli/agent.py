"""Minimal bundled conversation agent for ``bithuman serve`` (2.0 release, Phase 2).

A self-contained `livekit-agents` worker that supplies the *conversation* for
the avatar and lets ``bithuman serve`` render it. Topology **D2 — serve
renders**:

  browser ── LiveKit room ── this agent (OpenAI Realtime → speech)
                          └─ ``bithuman serve`` libessence (renders avatar video)

This process does the talking only; it never loads libessence. The avatar
dispatch + audio wiring is handled by an **inline** ``AvatarSession``
(see ``_avatar_bridge.py``) that posts to THIS serve's ``/launch`` via
``api_url`` — exactly the supported self-hosted path. The inline bridge
replaces ``livekit-plugins-bithuman`` to avoid its ``bithuman<1.12`` pin;
it mints the avatar token (publish-on-behalf of us), posts the launch,
waits for the avatar to join, and routes our speech to it over the
livekit-agents datastream. ``bithuman serve`` accepts the payload
(``agent_id`` aliases ``model_id``).

Spawned + lifecycle-managed by ``bithuman serve`` (Rust
``embedded_agent_worker.rs``). Run standalone for testing with:

    python -m bithuman_cli.agent start

Environment (the Rust parent sets these):

  LIVEKIT_URL, LIVEKIT_API_KEY, LIVEKIT_API_SECRET  — embedded livekit creds
  OPENAI_API_KEY                                    — the conversational agent (cloud mode)
  BITHUMAN_SERVE_URL    — e.g. http://127.0.0.1:8088 ; AvatarSession api_url
                          is `${BITHUMAN_SERVE_URL}/launch`
  BITHUMAN_MODEL_ID     — the agent code serve staged the model under
  BITHUMAN_AGENT_NAME   (default "bithuman")  — agent_name to register under
  BITHUMAN_API_SECRET   (optional) — passed to AvatarSession (serve ignores it;
                          the plugin requires it to be set for the JSON path)
  BITHUMAN_INSTRUCTIONS (optional) — system prompt
  BITHUMAN_VOICE        (optional, default "alloy") — OpenAI Realtime voice (cloud mode)
  BITHUMAN_AGENT_PORT   (default 8011) — worker HTTP port (Rust polls it).
                          ``BITHUMAN_BRAIN_PORT`` is accepted as a deprecated
                          alias for one release.

Local mode (set BITHUMAN_LOCAL=1; requires `pip install bithuman-cli[local]`):

  BITHUMAN_LOCAL=1        — flip the brain to whisper.cpp + llama.cpp + Supertonic
  BITHUMAN_LOCAL_WHISPER  (default "tiny.en")  — whisper.cpp model size
  BITHUMAN_LOCAL_LLM      (default "Qwen/Qwen2.5-0.5B-Instruct-GGUF") — HF repo
  BITHUMAN_LOCAL_LLM_FILE (default "qwen2.5-0.5b-instruct-q4_k_m.gguf") — GGUF file
  BITHUMAN_LOCAL_VOICE    (default "M1") — Supertonic voice preset (M1-M5/F1-F5)
  BITHUMAN_LOCAL_LANG     (default "en") — Supertonic language (31 supported)

Apache-2.0; (c) bitHuman.
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys

import aiohttp
import warnings
from pathlib import Path


def _load_dotbithuman_config() -> None:
    """Hydrate ``os.environ`` from ``~/.bithuman/config`` if it exists.

    Written by the Rust CLI's ``bithuman init`` wizard; loading it here
    means the brain inherits the same BITHUMAN_API_SECRET / OPENAI_API_KEY
    / BITHUMAN_LOCAL the user typed at first-time setup without needing
    a shell export. Existing env vars win (matches the Rust loader).
    Format: dotenv-style ``KEY=VALUE`` per line; ``#`` comments and
    blanks ignored; surrounding ``"``/``'`` stripped.
    """
    cfg = Path.home() / ".bithuman" / "config"
    try:
        text = cfg.read_text()
    except (FileNotFoundError, OSError):
        return
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        key = key.strip()
        if not key or key in os.environ:
            continue
        os.environ[key] = val.strip().strip('"').strip("'")


# Run BEFORE the env-var checks in ``_preflight_brain`` / ``_build_agent``.
_load_dotbithuman_config()


from livekit.agents import AgentServer, JobContext, RoomOutputOptions, WorkerOptions, cli
from livekit.agents.voice import Agent, AgentSession
from livekit.plugins import openai

# Inline avatar bridge — replaces `livekit-plugins-bithuman` to avoid its
# `bithuman<1.12` pin. See `_avatar_bridge.py` for the sunset path.
from ._avatar_bridge import AvatarSession as _RemoteAvatarSession

logger = logging.getLogger("bithuman.agent")


def _truthy(name: str) -> bool:
    v = os.getenv(name, "")
    return bool(v) and v != "0" and v.lower() != "false"


def _require(name: str) -> str:
    val = os.getenv(name)
    if not val:
        raise RuntimeError(
            f"{name} is required (set by `bithuman serve` when it spawns the brain)"
        )
    return val


def _preflight_brain() -> None:
    """Validate the selected brain mode has its prerequisites BEFORE the
    worker tries to connect. Fails fast with an actionable message rather
    than letting a downstream 401/ImportError surface mid-session.

    Modes (mutually exclusive; BITHUMAN_LOCAL wins if both):
      * BITHUMAN_LOCAL=1 → on-device. Needs `pip install 'bithuman-cli[local]'`.
      * default          → OpenAI Realtime. Needs OPENAI_API_KEY.

    Smoke-test path (BITHUMAN_AVATAR_ONLY=1) skips both — no brain.
    """
    if _truthy("BITHUMAN_AVATAR_ONLY"):
        return

    local = _truthy("BITHUMAN_LOCAL")
    has_openai_key = bool(os.getenv("OPENAI_API_KEY"))

    if local and has_openai_key:
        logger.info(
            "Using local brain (BITHUMAN_LOCAL=1 takes precedence over OPENAI_API_KEY)."
        )

    if local:
        missing: list[str] = []
        try:
            import livekit.plugins.silero  # noqa: F401
        except ImportError:
            missing.append("livekit-plugins-silero")
        try:
            import supertonic  # noqa: F401
        except ImportError:
            missing.append("supertonic")
        try:
            import pywhispercpp  # noqa: F401
        except ImportError:
            missing.append("pywhispercpp")
        try:
            import llama_cpp  # noqa: F401
        except ImportError:
            missing.append("llama-cpp-python")
        if missing:
            print(
                "\n  bithuman: BITHUMAN_LOCAL=1 is set but local-mode "
                "dependencies are missing.\n"
                f"  Missing: {', '.join(missing)}\n\n"
                "  Install:\n"
                "    pip install 'bithuman-cli[local]'\n\n"
                "  Or unset BITHUMAN_LOCAL to use the cloud brain "
                "(needs OPENAI_API_KEY).\n",
                file=sys.stderr,
            )
            sys.exit(2)
        return

    # Cloud, in precedence order:
    #   1. bitHuman-managed brain (logged in, no user key) -> credits auto-metered
    #   2. BYO OpenAI key (OPENAI_API_KEY)
    #   3. neither -> actionable error
    if _managed_brain():
        logger.info("Using the bitHuman-managed brain (OpenAI Realtime; credits auto-metered).")
        return
    if not has_openai_key:
        print(
            "\n  bithuman: no brain configured.\n\n"
            "  Sign in to use the bitHuman-managed brain (no OpenAI key needed):\n"
            "    bithuman login\n\n"
            "  Or bring your own OpenAI key:\n"
            "    export OPENAI_API_KEY=sk-...\n\n"
            "  Or run on-device (no API key, no outbound network):\n"
            "    pip install 'bithuman-cli[local]'\n"
            "    BITHUMAN_LOCAL=1 bithuman run <model.imx>\n",
            file=sys.stderr,
        )
        sys.exit(2)
    logger.info("Using cloud brain (OpenAI Realtime, your OPENAI_API_KEY).")


def _api_base() -> str:
    return os.getenv("BITHUMAN_API_BASE", "https://api.bithuman.ai").rstrip("/")


def _managed_brain() -> bool:
    """True when bitHuman provides the OpenAI brain (logged in, no user OpenAI
    key) -> credits auto-metered. The CLI sets BITHUMAN_API_SECRET on the worker
    env in this case."""
    return bool(os.getenv("BITHUMAN_API_SECRET")) and not os.getenv("OPENAI_API_KEY")


def _mint_realtime_token() -> tuple[str, str]:
    """Mint a short-lived OpenAI Realtime client secret from bitHuman's
    api-secret-gated endpoint (the platform OpenAI key stays server-side).
    Returns (ek_value, model)."""
    import json as _json
    import urllib.error as _urlerr
    import urllib.request as _urlreq

    api_secret = os.getenv("BITHUMAN_API_SECRET", "")
    model = os.getenv("BITHUMAN_REALTIME_MODEL", "gpt-realtime-mini")
    req = _urlreq.Request(
        f"{_api_base()}/v1/realtime/ephemeral-token",
        data=_json.dumps({"model": model}).encode(),
        headers={
            "api-secret": api_secret,
            "Content-Type": "application/json",
            # A real User-Agent is required: the default "Python-urllib/x.y"
            # is blocked at the edge (Cloudflare) with a 403 before it reaches
            # the API.
            "User-Agent": "bithuman-cli",
        },
        method="POST",
    )
    try:
        with _urlreq.urlopen(req, timeout=15) as r:
            payload = _json.loads(r.read().decode())
    except _urlerr.HTTPError as e:
        # Map the status precisely — do NOT call everything "out of credits".
        if e.code == 402:
            raise RuntimeError(
                "You are out of credits for the bitHuman-managed brain. "
                "Top up at https://www.bithuman.ai/upgrade"
            ) from e
        if e.code == 429:
            raise RuntimeError(
                "Too many sessions started just now — wait a moment and retry."
            ) from e
        if e.code in (401, 403):
            raise RuntimeError(
                f"managed brain: not authorized to mint a token (HTTP {e.code}). "
                "Try `bithuman login` again."
            ) from e
        raise RuntimeError(f"managed brain: token mint failed (HTTP {e.code})") from e
    data = payload.get("data", payload)
    value = data.get("value")
    if not value:
        raise RuntimeError(f"managed brain: no token in response: {payload}")
    return value, data.get("model", model)


async def _billing_heartbeat(ctx: JobContext) -> None:
    """Meter the managed voice-chat session at 10 credits/min via auth-service:
    a beat at start + every 60s; a 402/403 (out of credits) ends the session."""
    import hashlib
    import uuid

    api_secret = os.getenv("BITHUMAN_API_SECRET", "")
    if not api_secret:
        return
    url = f"{_api_base()}/v1/runtime-tokens/request"
    txn = str(uuid.uuid4())
    body = {
        "fingerprint": hashlib.sha256(txn.encode()).hexdigest()[:32],
        "transaction_id": txn,
        "billing_type": "agent-voice-chat",
        "tags": "bithuman-cli",
    }
    headers = {"api-secret": api_secret, "Content-Type": "application/json"}
    timeout = aiohttp.ClientTimeout(total=30)
    try:
        while True:
            try:
                async with aiohttp.ClientSession(timeout=timeout) as _s:
                    async with _s.post(url, headers=headers, json=body) as resp:
                        if resp.status in (402, 403):
                            logger.error(
                                "Voice chat: out of credits - ending session. "
                                "Top up at https://www.bithuman.ai/upgrade"
                            )
                            await ctx.room.disconnect()
                            return
                        if resp.status != 200:
                            logger.warning(f"billing beat HTTP {resp.status}")
            except Exception as e:
                logger.warning(f"billing beat error: {e}")
            await asyncio.sleep(60)
    except asyncio.CancelledError:
        return


def _build_agent() -> Agent:
    """Construct the conversation Agent.

    Cloud (default): one OpenAI Realtime model — STT, LLM, and TTS in one call.

    Local (BITHUMAN_LOCAL=1): on-device stack assembled from the bundled
    `bithuman_cli.local_plugins` namespace — whisper.cpp for STT, llama.cpp for
    LLM, Supertonic for TTS. Requires the `[local]` install extra.
    """
    instructions = os.getenv(
        "BITHUMAN_INSTRUCTIONS",
        "You are a helpful, friendly avatar assistant. Keep replies concise and natural.",
    )

    if os.getenv("BITHUMAN_AVATAR_ONLY"):
        # Smoke-test path: no STT/LLM/TTS, just an Agent shell so the
        # session loop spins. The avatar still publishes its idle frame
        # (and any audio that gets pushed externally renders normally).
        return Agent(instructions=instructions)

    if os.getenv("BITHUMAN_LOCAL"):
        try:
            # Phase B split: local plugins are now siblings under
            # `bithuman_cli/` (this file's package), not on the SDK.
            # Use the absolute package path — agent.py is invoked as a
            # script (`python <abs>/agent.py start`) by the Rust
            # embedded_agent_worker, so relative imports don't resolve.
            # site-packages is on sys.path, so `bithuman_cli.*` does.
            from bithuman_cli.local_plugins import (
                LlamaCppLLM, SupertonicTTS, WhisperSTT,
            )
        except ImportError as e:
            raise RuntimeError(
                "BITHUMAN_LOCAL=1 requires the local extras. "
                "Install with: pip install 'bithuman-cli[local]'"
            ) from e

        return Agent(
            instructions=instructions,
            stt=WhisperSTT(
                model_size=os.getenv("BITHUMAN_LOCAL_WHISPER", "tiny.en"),
            ),
            llm=LlamaCppLLM(
                model_repo=os.getenv(
                    "BITHUMAN_LOCAL_LLM",
                    "Qwen/Qwen2.5-0.5B-Instruct-GGUF",
                ),
                model_file=os.getenv(
                    "BITHUMAN_LOCAL_LLM_FILE",
                    "qwen2.5-0.5b-instruct-q4_k_m.gguf",
                ),
                max_tokens=128,
            ),
            tts=SupertonicTTS(
                voice=os.getenv("BITHUMAN_LOCAL_VOICE", "M1"),
                language=os.getenv("BITHUMAN_LOCAL_LANG", "en"),
                total_steps=8,
            ),
        )

    if _managed_brain():
        # bitHuman mints a short-lived OpenAI Realtime client secret; the
        # platform OpenAI key never reaches this process.
        token, model = _mint_realtime_token()
        return Agent(
            instructions=instructions,
            llm=openai.realtime.RealtimeModel(
                voice=os.getenv("BITHUMAN_VOICE", "alloy"),
                api_key=token,
                model=model,
            ),
        )

    return Agent(
        instructions=instructions,
        llm=openai.realtime.RealtimeModel(voice=os.getenv("BITHUMAN_VOICE", "alloy")),
    )


def _build_session() -> AgentSession:
    """Build the AgentSession. Local mode needs a VAD; cloud Realtime brings its own."""
    if os.getenv("BITHUMAN_LOCAL"):
        from livekit.plugins import silero
        return AgentSession(vad=silero.VAD.load())
    return AgentSession()


async def entrypoint(ctx: JobContext) -> None:
    _preflight_brain()
    await ctx.connect()

    session = _build_session()

    # Two avatar transports:
    #   1. **Local** (BITHUMAN_LOCAL_AVATAR=1 + BITHUMAN_MODEL_PATH):
    #      AvatarSession loads the model in this process via
    #      AsyncBithuman.create() — works for any model_type (essence,
    #      expression, elevate). The brain renders + publishes its own
    #      video track. Used for `bithuman run avatar_elevate.imx`
    #      where the Rust serve doesn't yet host elevate.
    #   2. **Remote** (BITHUMAN_SERVE_URL): AvatarSession posts to the
    #      serve's /launch, the serve renders. The default for essence
    #      where the Rust LibEssenceRuntime is the production path.
    local_model = os.getenv("BITHUMAN_MODEL_PATH")
    if os.getenv("BITHUMAN_LOCAL_AVATAR") and local_model:
        # Local in-process avatar still requires the upstream plugin
        # (it loads `AsyncBithuman` + bundles the `BithumanGenerator`).
        # Imported lazily so the default cloud path doesn't need it.
        from livekit.plugins import bithuman as _lk_bh  # type: ignore
        avatar = _lk_bh.AvatarSession(
            model_path=local_model,
            api_secret=os.getenv("BITHUMAN_API_SECRET")
            or os.getenv("BITHUMAN_API_KEY")
            or "self-hosted",
        )
    else:
        serve_url = _require("BITHUMAN_SERVE_URL").rstrip("/")
        avatar = _RemoteAvatarSession(
            api_url=f"{serve_url}/launch",
            # serve doesn't validate this (its libessence is already authed), but
            # the plugin requires api_secret to be set for the JSON dispatch path.
            api_secret=os.getenv("BITHUMAN_API_SECRET")
            or os.getenv("BITHUMAN_API_KEY")
            or "self-hosted",
            avatar_id=_require("BITHUMAN_MODEL_ID"),
            model="essence",
        )
    await avatar.start(session, room=ctx.room)

    # Meter the managed voice-chat brain at 10 credits/min for the session
    # lifetime (no-op for BYO-key / local brains). Cancelled on shutdown.
    if _managed_brain():
        _hb_task = asyncio.create_task(_billing_heartbeat(ctx))
        if hasattr(ctx, "add_shutdown_callback"):
            async def _stop_billing() -> None:
                _hb_task.cancel()

            ctx.add_shutdown_callback(_stop_billing)

    await session.start(
        agent=_build_agent(),
        room=ctx.room,
        # Speech is delivered to serve's avatar via the datastream output that
        # AvatarSession wired above; don't also publish a room audio track.
        room_output_options=RoomOutputOptions(audio_enabled=False),
    )


def _agent_port() -> int:
    """Resolve the worker HTTP port.

    ``BITHUMAN_AGENT_PORT`` is the canonical name; ``BITHUMAN_BRAIN_PORT``
    is accepted as a deprecated alias for one release (the file used to be
    called ``serve_brain.py``). New name wins when both are set.
    """
    new = os.getenv("BITHUMAN_AGENT_PORT")
    old = os.getenv("BITHUMAN_BRAIN_PORT")
    if new:
        return int(new)
    if old:
        warnings.warn(
            "BITHUMAN_BRAIN_PORT is deprecated; use BITHUMAN_AGENT_PORT instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return int(old)
    return 8011


def _write_ready_marker(*_args: object) -> None:
    """Signal the Rust parent that the worker has REGISTERED with LiveKit.

    livekit-agents binds the worker HTTP port (``port=`` below) the instant the
    process starts — before it finishes registering with the LiveKit server. A
    dispatch created in that gap is silently dropped, so the first browser tab
    (``bithuman run`` auto-opens it the moment serve is "live") lands in an
    agent-less room and shows a blank canvas. The Rust parent
    (embedded_agent_worker.rs) waits for this marker — written from the
    ``worker_registered`` event — before reporting ready / opening the browser,
    so the first dispatch is always honored. Best-effort + atomic; the path is
    supplied by the parent via ``BITHUMAN_AGENT_READY_FILE``.
    """
    path = os.getenv("BITHUMAN_AGENT_READY_FILE")
    if not path:
        return
    try:
        tmp = f"{path}.tmp"
        with open(tmp, "w") as f:
            f.write("registered\n")
        os.replace(tmp, path)  # atomic publish — parent sees it only once complete
    except OSError:
        pass


def main() -> None:
    # Build the AgentServer explicitly (what cli.run_app does internally for a
    # WorkerOptions) so we can subscribe to its lifecycle events before running.
    server = AgentServer.from_server_options(
        WorkerOptions(
            entrypoint_fnc=entrypoint,
            agent_name=os.getenv("BITHUMAN_AGENT_NAME", "bithuman"),
            # HTTP port the worker binds on startup. The Rust parent no longer
            # treats this port opening as "ready" — it waits for the
            # registration marker written below, because the port opens ~0.5s
            # before the worker can actually be dispatched to.
            port=_agent_port(),
        )
    )
    # Fires once the worker is registered with the (embedded) LiveKit server and
    # can service dispatches. cli.run_app runs this exact instance, so the
    # listener is honored.
    server.on("worker_registered", _write_ready_marker)
    cli.run_app(server)


if __name__ == "__main__":
    main()
