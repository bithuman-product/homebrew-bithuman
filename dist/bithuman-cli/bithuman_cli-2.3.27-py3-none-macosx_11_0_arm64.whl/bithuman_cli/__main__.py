"""bithuman-cli module entry: `python -m bithuman_cli <command>`.

Equivalent to running the `bithuman` console script installed by this
wheel — both call `bithuman_cli._entry:main`, which locates the
bundled Rust binary at `bithuman_cli/_bin/bithuman` and `execvpe`s
into it.
"""
import sys

from ._entry import main

sys.exit(main())
