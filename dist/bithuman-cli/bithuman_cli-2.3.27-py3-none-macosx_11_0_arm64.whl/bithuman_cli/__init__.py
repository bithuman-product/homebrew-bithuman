"""bithuman-cli — the bitHuman command-line tool.

Internal package. Users interact via the `bithuman` console script
installed by this wheel:

    bithuman run model.imx        # live avatar
    bithuman render -a in.wav -o out.mp4
    bithuman doctor

Programmatic invocation is also supported:

    python -m bithuman_cli  # equivalent to running `bithuman`

For embedding the bitHuman runtime in a Python application, use the
bitHuman SDK directly (this wheel depends on it):

    from bithuman import AsyncBithuman
"""
from __future__ import annotations

# Keep aligned with cpp/bindings/python-cli/pyproject.toml.
__version__ = "2.3.0"
