"""Supertonic 3 TTS as a LiveKit-agents plugin.

Wraps the official `supertonic` PyPI package (1.3.x+), which handles
auto-downloading the ~380 MB ONNX models from HuggingFace on first use.

Drop-in for `cartesia.TTS()` / `openai.TTS()` in `Agent(...)`. No API key,
no separate assets directory to configure.
"""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass

import numpy as np
from livekit.agents.tts import TTS, ChunkedStream, TTSCapabilities
from livekit.agents.types import DEFAULT_API_CONNECT_OPTIONS, APIConnectOptions

from ._trace import event, trace


@dataclass
class _Opts:
    voice: str = "M1"
    language: str = "en"
    total_steps: int = 8
    speed: float = 1.05
    sample_rate: int = 24000  # what we EMIT; supertonic native is 44.1 kHz


class SupertonicTTS(TTS):
    """On-device Supertonic 3 TTS plugin for livekit-agents."""

    def __init__(
        self,
        *,
        voice: str = "M1",
        language: str = "en",
        total_steps: int = 8,
        speed: float = 1.05,
        sample_rate: int = 24000,
        model: str = "supertonic-3",
        model_dir: str | None = None,
    ) -> None:
        super().__init__(
            capabilities=TTSCapabilities(streaming=False),
            sample_rate=sample_rate,
            num_channels=1,
        )
        self._opts = _Opts(
            voice=voice, language=language, total_steps=total_steps,
            speed=speed, sample_rate=sample_rate,
        )

        try:
            from supertonic import TTS as SupertonicCore  # type: ignore
        except ImportError as e:
            raise ImportError(
                "supertonic required: pip install supertonic"
            ) from e

        with trace("tts", "model_load", model=model):
            # auto_download=True downloads ~380 MB to ~/.cache/supertonic
            self._core = SupertonicCore(
                model=model, model_dir=model_dir, auto_download=True,
            )
        self._native_sr = 44100  # supertonic always emits 44.1 kHz

        # Preload the requested voice so first synthesize() is warm
        self._style_cache: dict[str, object] = {}
        self._load_style(voice)

    def _load_style(self, voice: str):
        if voice not in self._style_cache:
            with trace("tts", "voice_load", voice=voice):
                self._style_cache[voice] = self._core.get_voice_style(voice)
        return self._style_cache[voice]

    def update_options(
        self,
        *,
        voice: str | None = None,
        language: str | None = None,
        total_steps: int | None = None,
        speed: float | None = None,
    ) -> None:
        if voice is not None:
            self._opts.voice = voice
            self._load_style(voice)
        if language is not None:
            self._opts.language = language
        if total_steps is not None:
            self._opts.total_steps = total_steps
        if speed is not None:
            self._opts.speed = speed

    def synthesize(
        self,
        text: str,
        *,
        conn_options: APIConnectOptions = DEFAULT_API_CONNECT_OPTIONS,
    ) -> ChunkedStream:
        return _SupertonicChunkedStream(
            tts=self, input_text=text, conn_options=conn_options
        )

    def _synth_blocking(self, text: str) -> bytes:
        style = self._load_style(self._opts.voice)
        with trace("tts", "synthesize",
                   chars=len(text), voice=self._opts.voice,
                   lang=self._opts.language, steps=self._opts.total_steps):
            wav, _dur = self._core.synthesize(
                text, style,
                total_steps=self._opts.total_steps,
                speed=self._opts.speed,
                lang=self._opts.language,
            )
        audio = np.asarray(wav).squeeze().astype(np.float32)
        audio_s = len(audio) / self._native_sr
        if self._native_sr != self._opts.sample_rate:
            from ._resample import resample_f32
            with trace("tts", "resample",
                       src_sr=self._native_sr, dst_sr=self._opts.sample_rate,
                       audio_s=f"{audio_s:.2f}"):
                audio = resample_f32(audio, self._native_sr, self._opts.sample_rate)
        audio = np.clip(audio, -1.0, 1.0)
        pcm16 = (audio * 32767.0).astype(np.int16)
        event("tts", "result", audio_s=f"{audio_s:.2f}", bytes=len(pcm16) * 2)
        return pcm16.tobytes()


class _SupertonicChunkedStream(ChunkedStream):
    def __init__(self, *, tts: SupertonicTTS, input_text: str,
                 conn_options: APIConnectOptions) -> None:
        super().__init__(tts=tts, input_text=input_text, conn_options=conn_options)
        self._tts_plugin: SupertonicTTS = tts

    async def _run(self, output_emitter) -> None:
        request_id = f"supertonic-{int(time.time()*1000)}"
        output_emitter.initialize(
            request_id=request_id,
            sample_rate=self._tts_plugin.sample_rate,
            num_channels=self._tts_plugin.num_channels,
            mime_type="audio/pcm",
            frame_size_ms=200,
            stream=False,
        )
        pcm_bytes = await asyncio.to_thread(
            self._tts_plugin._synth_blocking, self._input_text
        )
        output_emitter.push(pcm_bytes)
        output_emitter.flush()
