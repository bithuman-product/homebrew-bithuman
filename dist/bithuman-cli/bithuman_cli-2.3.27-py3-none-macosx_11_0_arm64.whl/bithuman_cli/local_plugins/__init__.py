"""On-device STT / LLM / TTS plugins for `BITHUMAN_LOCAL=1`.

Shipped by the `bithuman-cli[local]` install extra. These are
livekit-agents plugin classes (`STT`, `LLM`, `TTS` subclasses) that
the bundled `bithuman_cli.agent` entrypoint wires into the
conversation `Agent` when the local-mode env var is set.

Imports are lazy by way of being module-level — the heavy backend
dependencies (`pywhispercpp`, `llama-cpp-python`, `supertonic`) are
only imported at *class instantiation* time, so a CLI install that
lacks the `[local]` extra can still `import bithuman_cli` without
ImportError. The `try/except` here mirrors that contract at the
`from bithuman_cli.local_plugins import …` level for callers that
want to detect availability without instantiating.
"""
from __future__ import annotations

try:
    from .stt import WhisperSTT  # noqa: F401
    from .llm import LlamaCppLLM  # noqa: F401
    from .tts import SupertonicTTS  # noqa: F401
    from ._trace import configure_logging, new_turn_id  # noqa: F401
    _LOCAL_AVAILABLE = True
except ImportError:
    _LOCAL_AVAILABLE = False

__all__ = []
if _LOCAL_AVAILABLE:
    __all__ += [
        "WhisperSTT",
        "LlamaCppLLM",
        "SupertonicTTS",
        "configure_logging",
        "new_turn_id",
    ]
