"""Structured tracing for the local stack.

Every stage logs as: [trace] component=… stage=… duration_ms=… extra…
so timings line up cleanly in logs / log shippers / grep. Each event
also carries an `event_id` (uuid4 short) so a single user-turn can be
reconstructed from interleaved STT/LLM/TTS logs.
"""
from __future__ import annotations

import contextlib
import os
import sys
import time
import uuid
from typing import Any

from loguru import logger

# Format that stays readable in a terminal but is also one-line-per-event
# so a log shipper / `grep` can parse it. Stage names are stable enums.
_LOG_FORMAT = (
    "<green>{time:HH:mm:ss.SSS}</green> "
    "<level>{level: <7}</level> "
    "<cyan>{extra[component]: <10}</cyan> "
    "<magenta>{extra[stage]: <14}</magenta> "
    "<yellow>{extra[duration_ms]: >7}ms</yellow> "
    "{message}"
)


def configure_logging(level: str | None = None) -> None:
    """Idempotent — call once at process startup."""
    level = (level or os.getenv("BITHUMAN_LOCAL_LOG", "INFO")).upper()
    logger.remove()
    logger.add(
        sys.stderr,
        level=level,
        format=_LOG_FORMAT,
        # Provide defaults so log calls without extras still render.
        filter=lambda rec: rec["extra"].setdefault("component", "-")
        and rec["extra"].setdefault("stage", "-")
        and rec["extra"].setdefault("duration_ms", "") is not None,
    )
    logger.bind(component="trace", stage="boot", duration_ms="").info(
        "logging configured  level={}", level
    )


def new_turn_id() -> str:
    """Short id to correlate STT/LLM/TTS for one user turn."""
    return uuid.uuid4().hex[:8]


@contextlib.contextmanager
def trace(component: str, stage: str, **extra: Any):
    """Context manager: logs duration + any extras when the block exits.

    Usage:
        with trace("tts", "synthesize", turn=tid, text_len=len(text)):
            wav = synth(text)
    """
    t0 = time.perf_counter()
    bound = logger.bind(component=component, stage=stage, duration_ms="")
    bound.debug("start  {}", " ".join(f"{k}={v}" for k, v in extra.items()))
    try:
        yield
        dt_ms = int((time.perf_counter() - t0) * 1000)
        logger.bind(component=component, stage=stage, duration_ms=dt_ms).info(
            "{}",
            " ".join(f"{k}={v}" for k, v in extra.items()) or "ok",
        )
    except Exception as e:
        dt_ms = int((time.perf_counter() - t0) * 1000)
        logger.bind(component=component, stage=stage, duration_ms=dt_ms).error(
            "FAILED {} -> {}",
            " ".join(f"{k}={v}" for k, v in extra.items()),
            e,
        )
        raise


def event(component: str, stage: str, duration_ms: int | str = "", **extra: Any) -> None:
    """Log a single point-in-time event with optional pre-measured duration."""
    logger.bind(component=component, stage=stage, duration_ms=duration_ms).info(
        "{}", " ".join(f"{k}={v}" for k, v in extra.items()) or "ok"
    )
