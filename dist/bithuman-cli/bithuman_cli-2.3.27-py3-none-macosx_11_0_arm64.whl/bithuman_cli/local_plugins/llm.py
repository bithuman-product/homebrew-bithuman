"""In-process llama.cpp LLM as a LiveKit-agents plugin.

No external server (no Ollama, no llama-server). Loads a GGUF model
directly from HuggingFace Hub on first use, runs in the same process.

Why this over `openai.LLM(base_url=ollama)`:
- ZERO setup: no `brew install ollama && ollama serve && ollama pull`
- Mobile-portable: same llama.cpp core runs on iOS/Android (Swift/Kotlin
  bindings exist; the GGUF file is bit-identical)
- Smaller default footprint: Qwen 2.5 0.5B-Instruct Q4_K_M ~400 MB
- Streamed tokens with no HTTP overhead

Defaults are picked for "runs anywhere":
  - Qwen2.5-0.5B-Instruct (Q4_K_M): 400 MB RAM, ~30 tok/s on M5 CPU
  - Context: 4096 tokens (configurable)
  - Threads: auto (logical CPUs / 2)

For better quality, swap to Qwen2.5-1.5B-Instruct (~1 GB) or
Llama-3.2-3B-Instruct (~2 GB) — same plugin, just change `model_repo`.
"""
from __future__ import annotations

import asyncio
import os
from dataclasses import dataclass
from typing import Any, AsyncIterator

from livekit.agents import llm
from livekit.agents.llm import (
    ChatChunk,
    ChatContext,
    ChoiceDelta,
    LLM,
    LLMStream,
)
from livekit.agents.types import (
    DEFAULT_API_CONNECT_OPTIONS,
    APIConnectOptions,
)
from livekit.agents.utils import shortuuid

from ._trace import event, trace


_DEFAULT_REPO = "Qwen/Qwen2.5-0.5B-Instruct-GGUF"
_DEFAULT_FILE = "qwen2.5-0.5b-instruct-q4_k_m.gguf"
_DEFAULT_CTX = 4096


@dataclass
class _Opts:
    model_repo: str = _DEFAULT_REPO
    model_file: str = _DEFAULT_FILE
    n_ctx: int = _DEFAULT_CTX
    n_threads: int | None = None
    n_gpu_layers: int = 0       # CPU-only by default for portability
    max_tokens: int = 256
    temperature: float = 0.7
    top_p: float = 0.9


class LlamaCppLLM(LLM):
    """In-process llama.cpp LLM plugin for livekit-agents."""

    def __init__(
        self,
        *,
        model_repo: str = _DEFAULT_REPO,
        model_file: str = _DEFAULT_FILE,
        n_ctx: int = _DEFAULT_CTX,
        n_threads: int | None = None,
        n_gpu_layers: int = 0,
        max_tokens: int = 256,
        temperature: float = 0.7,
        top_p: float = 0.9,
    ) -> None:
        super().__init__()
        self._opts = _Opts(
            model_repo=model_repo, model_file=model_file, n_ctx=n_ctx,
            n_threads=n_threads, n_gpu_layers=n_gpu_layers,
            max_tokens=max_tokens, temperature=temperature, top_p=top_p,
        )
        try:
            from llama_cpp import Llama  # type: ignore
        except ImportError as e:
            raise ImportError(
                "llama-cpp-python required: pip install llama-cpp-python"
            ) from e

        with trace("llm", "model_load", repo=model_repo, file=model_file,
                   n_ctx=n_ctx, gpu_layers=n_gpu_layers):
            # from_pretrained: download GGUF from HF Hub, cache to ~/.cache/huggingface
            self._llm = Llama.from_pretrained(
                repo_id=model_repo,
                filename=model_file,
                n_ctx=n_ctx,
                n_threads=n_threads,
                n_gpu_layers=n_gpu_layers,
                verbose=False,
            )

    def chat(
        self,
        *,
        chat_ctx: ChatContext,
        conn_options: APIConnectOptions = DEFAULT_API_CONNECT_OPTIONS,
        tools: list | None = None,
        parallel_tool_calls: bool | None = None,
        tool_choice: Any | None = None,
        extra_kwargs: Any | None = None,
    ) -> LLMStream:
        return _LlamaCppStream(
            llm=self,
            chat_ctx=chat_ctx,
            tools=tools or [],
            conn_options=conn_options,
        )


class _LlamaCppStream(LLMStream):
    def __init__(self, *, llm: LlamaCppLLM, chat_ctx: ChatContext,
                 tools: list, conn_options: APIConnectOptions) -> None:
        super().__init__(llm=llm, chat_ctx=chat_ctx, tools=tools, conn_options=conn_options)
        self._llm_plugin: LlamaCppLLM = llm

    async def _run(self) -> None:
        messages = _chat_ctx_to_messages(self._chat_ctx)
        request_id = f"llamacpp-{shortuuid()}"
        opts = self._llm_plugin._opts

        # llama.cpp streams sync; run the iterator in a thread and bridge
        # via an asyncio.Queue so we can await chunks.
        loop = asyncio.get_running_loop()
        q: asyncio.Queue = asyncio.Queue()
        SENTINEL = object()

        def _produce():
            try:
                with trace("llm", "generate",
                           messages=len(messages),
                           ctx=opts.n_ctx, max_tokens=opts.max_tokens):
                    for chunk in self._llm_plugin._llm.create_chat_completion(
                        messages=messages,
                        max_tokens=opts.max_tokens,
                        temperature=opts.temperature,
                        top_p=opts.top_p,
                        stream=True,
                    ):
                        delta = chunk["choices"][0].get("delta", {})
                        content = delta.get("content")
                        if content:
                            loop.call_soon_threadsafe(q.put_nowait, content)
            except Exception as e:
                loop.call_soon_threadsafe(q.put_nowait, e)
            finally:
                loop.call_soon_threadsafe(q.put_nowait, SENTINEL)

        worker = asyncio.create_task(asyncio.to_thread(_produce))

        ntok = 0
        try:
            while True:
                item = await q.get()
                if item is SENTINEL:
                    break
                if isinstance(item, Exception):
                    raise item
                ntok += 1
                self._event_ch.send_nowait(
                    ChatChunk(
                        id=request_id,
                        delta=ChoiceDelta(role="assistant", content=item),
                    )
                )
        finally:
            event("llm", "stream_done", tokens=ntok)
            await worker


def _chat_ctx_to_messages(ctx: ChatContext) -> list[dict[str, str]]:
    """Convert livekit ChatContext to llama.cpp's OpenAI-style messages."""
    out: list[dict[str, str]] = []
    for item in ctx.items:
        if item.type != "message":
            continue
        role = item.role  # "system" | "user" | "assistant"
        # ChatMessage.content is a list of TextContent | ImageContent
        text_parts = [c for c in item.content if isinstance(c, str)]
        if not text_parts:
            continue
        out.append({"role": role, "content": "\n".join(text_parts)})
    return out
