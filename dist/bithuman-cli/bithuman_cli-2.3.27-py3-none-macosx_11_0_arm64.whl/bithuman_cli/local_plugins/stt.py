"""whisper.cpp STT as a LiveKit-agents plugin.

Backend is `pywhispercpp` (whisper.cpp). Choice rationale:
- whisper.cpp has first-party iOS/Android builds — same .bin model files
  load via Swift/Kotlin. CTranslate2 (faster-whisper) doesn't.
- Pure C++, no PyTorch dependency.
- Auto-downloads GGML model files from HuggingFace on first use.

Default model is `tiny.en` (~75 MB, ~10× realtime on M5 CPU). Pass
model_size="base.en" (~145 MB), "small" (~480 MB, multilingual), or
"large-v3-turbo" (~1.5 GB) for better accuracy.
"""
from __future__ import annotations

import asyncio
import io
import os
import wave
from dataclasses import dataclass

import numpy as np
from livekit.agents import utils
from livekit.agents.stt import (
    STT,
    SpeechData,
    SpeechEvent,
    SpeechEventType,
    STTCapabilities,
)
from livekit.agents.types import NOT_GIVEN, APIConnectOptions, NotGivenOr

from ._trace import event, trace


@dataclass
class _Opts:
    model_size: str = "tiny.en"
    language: str = "en"
    n_threads: int = 4
    translate: bool = False


class WhisperSTT(STT):
    """On-device whisper.cpp STT plugin for livekit-agents."""

    _SAMPLE_RATE = 16000

    def __init__(
        self,
        *,
        model_size: str = "tiny.en",
        language: str = "en",
        n_threads: int = 4,
        translate: bool = False,
        models_dir: str | None = None,
    ) -> None:
        super().__init__(
            capabilities=STTCapabilities(streaming=False, interim_results=False),
        )
        self._opts = _Opts(
            model_size=model_size, language=language,
            n_threads=n_threads, translate=translate,
        )

        try:
            from pywhispercpp.model import Model  # type: ignore
        except ImportError as e:
            raise ImportError(
                "pywhispercpp required: pip install pywhispercpp"
            ) from e

        with trace("stt", "model_load", model=model_size, threads=n_threads):
            # pywhispercpp.Model auto-downloads from HuggingFace ggerganov/whisper.cpp
            self._model = Model(
                model=model_size,
                models_dir=models_dir,
                redirect_whispercpp_logs_to=False,  # silence the C++ stderr noise
                n_threads=n_threads,
            )

    def update_options(
        self,
        *,
        language: str | None = None,
        n_threads: int | None = None,
        translate: bool | None = None,
    ) -> None:
        if language is not None:
            self._opts.language = language
        if n_threads is not None:
            self._opts.n_threads = n_threads
        if translate is not None:
            self._opts.translate = translate

    async def _recognize_impl(
        self,
        buffer: utils.audio.AudioBuffer,
        *,
        language: NotGivenOr[str] = NOT_GIVEN,
        conn_options: APIConnectOptions,
    ) -> SpeechEvent:
        lang = language if utils.is_given(language) else self._opts.language

        frame = utils.audio.combine_frames(buffer)
        audio_i16 = np.frombuffer(frame.data, dtype=np.int16)
        if frame.sample_rate != self._SAMPLE_RATE:
            from ._resample import resample_f32
            audio_f32 = audio_i16.astype(np.float32) / 32768.0
            audio_f32 = resample_f32(audio_f32, frame.sample_rate, self._SAMPLE_RATE)
        else:
            audio_f32 = audio_i16.astype(np.float32) / 32768.0

        text, conf = await asyncio.to_thread(self._transcribe, audio_f32, lang)

        return SpeechEvent(
            type=SpeechEventType.FINAL_TRANSCRIPT,
            request_id="",
            alternatives=[
                SpeechData(language=lang, text=text, confidence=conf),
            ],
        )

    def _transcribe(self, audio_f32: np.ndarray, lang: str) -> tuple[str, float]:
        audio_s = len(audio_f32) / self._SAMPLE_RATE
        with trace("stt", "transcribe", audio_s=f"{audio_s:.2f}", lang=lang):
            # pywhispercpp wants float32 mono @ 16 kHz directly
            segments = self._model.transcribe(
                audio_f32,
                language=None if lang in ("auto", "") else lang,
                translate=self._opts.translate,
            )
        parts: list[str] = []
        # whisper.cpp segments expose .text but not avg_logprob; use 1.0
        # for the confidence stand-in (livekit only uses it for ordering).
        for seg in segments:
            t = seg.text if hasattr(seg, "text") else str(seg)
            parts.append(t)
        text = " ".join(p.strip() for p in parts).strip()
        event("stt", "result", text_len=len(text), preview=text[:80])
        return text, 1.0
