"""High-quality sample-rate conversion (soxr preferred, scipy fallback)."""
from __future__ import annotations

import numpy as np


def resample_f32(x: np.ndarray, sr_in: int, sr_out: int) -> np.ndarray:
    if sr_in == sr_out:
        return x
    try:
        import soxr  # type: ignore
        return soxr.resample(x, sr_in, sr_out)
    except ImportError:
        from math import gcd
        from scipy.signal import resample_poly  # type: ignore
        g = gcd(sr_in, sr_out)
        return resample_poly(x, sr_out // g, sr_in // g).astype(np.float32)
