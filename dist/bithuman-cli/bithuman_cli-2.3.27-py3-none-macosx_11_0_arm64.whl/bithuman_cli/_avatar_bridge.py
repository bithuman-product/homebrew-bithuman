"""Inline LiveKit avatar bridge — replaces `livekit-plugins-bithuman`.

WHY THIS EXISTS
---------------
Upstream `livekit-plugins-bithuman` pins `bithuman<1.12`, which blocks
installs of our 2.x SDK wheel. Until the upstream pin relaxes (or our
PR lands on PyPI), `pip install bithuman-cli` would fail to resolve.

Rather than wait, we re-implement the small slice of `AvatarSession`
that the CLI actually uses — the *cloud* / remote-serve path — directly
on top of livekit-agents primitives. This drops a transitive dependency
chain (`bithuman-cli → livekit-plugins-bithuman → bithuman<1.12`) and
makes `pip install bithuman-cli` resolve cleanly on its own.

SCOPE — only what `bithuman_cli.agent` calls:
    avatar = AvatarSession(
        api_url=f"{serve_url}/launch",
        api_secret=...,
        avatar_id=...,
        model="essence",
    )
    await avatar.start(session, room=ctx.room)

We do NOT reimplement:
  * Local in-process runtime (`model_path`/`runtime` kwargs) — `agent.py`
    has its own `BITHUMAN_LOCAL_AVATAR` branch.
  * Custom avatar images (`avatar_image=`) — CLI never sets these.
  * The multipart/form-data path for `auth.api.bithuman.ai` / expression
    workers — CLI only talks to `bithuman serve`'s `/launch` JSON endpoint.
  * `BithumanGenerator` / `VideoGenerator` — used only by the local path.

SUNSET PATH
-----------
When upstream relaxes its `bithuman<1.12` pin (tracked in pyproject.toml),
delete this file and switch `agent.py` back to:

    from livekit.plugins import bithuman as lk_bh
    avatar = lk_bh.AvatarSession(...)

The protocol is identical (this file is a literal extract), so the swap
is mechanical and behaviour-preserving.

Apache-2.0; (c) bitHuman.
"""

from __future__ import annotations

import asyncio
import logging
import os
from typing import Optional

import aiohttp
from livekit import api, rtc
from livekit.agents import (
    DEFAULT_API_CONNECT_OPTIONS,
    APIConnectionError,
    APIConnectOptions,
    APIStatusError,
    get_job_context,
    utils,
)
from livekit.agents.types import ATTRIBUTE_PUBLISH_ON_BEHALF
from livekit.agents.voice import AgentSession
from livekit.agents.voice.avatar import (
    AvatarSession as BaseAvatarSession,
    DataStreamAudioOutput,
)

logger = logging.getLogger("bithuman_cli.avatar")


_AVATAR_AGENT_IDENTITY = "bithuman-avatar-agent"
_AVATAR_AGENT_NAME = "bithuman-avatar-agent"


class BitHumanException(Exception):
    """Raised by the inline avatar bridge for misconfiguration or launch errors."""


class AvatarSession(BaseAvatarSession):
    """Drop-in replacement for `livekit.plugins.bithuman.AvatarSession`,
    cloud-mode only.

    POSTs an avatar-launch request to ``api_url`` (i.e.
    ``<bithuman-serve>/launch``), then routes the agent's TTS audio to the
    spawned avatar participant via livekit-agents' ``DataStreamAudioOutput``.
    The serve process publishes the rendered video track into the room
    on the avatar participant's behalf.
    """

    def __init__(
        self,
        *,
        api_url: str,
        api_secret: str,
        avatar_id: str,
        model: str = "essence",
        conn_options: APIConnectOptions = DEFAULT_API_CONNECT_OPTIONS,
        avatar_participant_identity: Optional[str] = None,
        avatar_participant_name: Optional[str] = None,
    ) -> None:
        super().__init__()
        if not api_url:
            raise BitHumanException("api_url is required")
        if not api_secret:
            raise BitHumanException("api_secret is required")
        if not avatar_id:
            raise BitHumanException("avatar_id is required")

        self._api_url = api_url
        self._api_secret = api_secret
        self._avatar_id = avatar_id
        self._model = model
        self._conn_options = conn_options
        self._avatar_participant_identity = (
            avatar_participant_identity or _AVATAR_AGENT_IDENTITY
        )
        self._avatar_participant_name = (
            avatar_participant_name or _AVATAR_AGENT_NAME
        )
        self._http_session: Optional[aiohttp.ClientSession] = None

    @property
    def avatar_identity(self) -> str:
        return self._avatar_participant_identity

    @property
    def provider(self) -> str:
        return "bithuman"

    async def start(
        self,
        agent_session: AgentSession,
        room: rtc.Room,
        *,
        livekit_url: Optional[str] = None,
        livekit_api_key: Optional[str] = None,
        livekit_api_secret: Optional[str] = None,
    ) -> None:
        # Base class: registers shutdown callback, starts the
        # wait-for-avatar-join task, wires conversation_item_added.
        await super().start(agent_session, room)

        livekit_url = livekit_url or os.getenv("LIVEKIT_URL")
        livekit_api_key = livekit_api_key or os.getenv("LIVEKIT_API_KEY")
        livekit_api_secret = livekit_api_secret or os.getenv("LIVEKIT_API_SECRET")
        if not livekit_url or not livekit_api_key or not livekit_api_secret:
            raise BitHumanException(
                "livekit_url, livekit_api_key, and livekit_api_secret must be "
                "set by arguments or environment variables"
            )

        # Mint a JWT for the avatar participant. The
        # ATTRIBUTE_PUBLISH_ON_BEHALF attribute lets serve publish video
        # tracks attributed to our local agent participant.
        job_ctx = get_job_context()
        local_participant_identity = job_ctx.local_participant_identity

        attributes: dict[str, str] = {
            ATTRIBUTE_PUBLISH_ON_BEHALF: local_participant_identity,
            "api_secret": self._api_secret,
            "agent_id": self._avatar_id,
        }

        livekit_token = (
            api.AccessToken(api_key=livekit_api_key, api_secret=livekit_api_secret)
            .with_kind("agent")
            .with_identity(self._avatar_participant_identity)
            .with_name(self._avatar_participant_name)
            .with_grants(api.VideoGrants(room_join=True, room=room.name))
            .with_attributes(attributes)
            .to_jwt()
        )

        logger.debug("starting avatar session")
        await self._launch(livekit_url, livekit_token, room.name)

        # Route agent TTS into the avatar over the LiveKit data stream.
        # The avatar reads this audio and renders matching lipsync video.
        agent_session.output.audio = DataStreamAudioOutput(
            room=room,
            destination_identity=self._avatar_participant_identity,
            wait_playback_start=False,
        )

    async def _launch(
        self, livekit_url: str, livekit_token: str, room_name: str
    ) -> None:
        """POST the avatar-launch request to ``api_url`` (bithuman-serve's
        ``/launch``) using the JSON format expected by serve.

        The CLI always talks to a custom self-hosted serve endpoint —
        never the default ``auth.api.bithuman.ai`` BitHuman cloud — but
        serve consumes the same JSON shape as the upstream plugin's
        default-API path (``mode: cpu`` + ``agent_id`` + ``api-secret``
        header). No multipart/form-data path needed.
        """
        json_data = {
            "livekit_url": livekit_url,
            "livekit_token": livekit_token,
            "room_name": room_name,
            "mode": "cpu" if self._model == "essence" else "gpu",
            "agent_id": self._avatar_id,
        }
        headers = {
            "Content-Type": "application/json",
            "api-secret": self._api_secret,
        }

        last_err: Optional[Exception] = None
        for i in range(self._conn_options.max_retry):
            try:
                async with self._ensure_http_session().post(
                    self._api_url,
                    headers=headers,
                    json=json_data,
                    timeout=aiohttp.ClientTimeout(
                        sock_connect=self._conn_options.timeout
                    ),
                ) as response:
                    if not response.ok:
                        text = await response.text()
                        raise APIStatusError(
                            "Server returned an error",
                            status_code=response.status,
                            body=text,
                        )
                    return
            except Exception as e:
                last_err = e
                if isinstance(e, APIConnectionError):
                    logger.warning(
                        "failed to call bithuman avatar api",
                        extra={"error": str(e)},
                    )
                else:
                    logger.exception("failed to call bithuman avatar api")
                if i < self._conn_options.max_retry - 1:
                    await asyncio.sleep(self._conn_options.retry_interval)

        raise APIConnectionError(
            f"Failed to start Bithuman Avatar Session after "
            f"{self._conn_options.max_retry} retries: {last_err}"
        )

    def _ensure_http_session(self) -> aiohttp.ClientSession:
        if self._http_session is None:
            self._http_session = utils.http_context.http_session()
        return self._http_session
