"""Python entry shim for the bundled `bithuman` Rust CLI.

The wheel ships the Rust binary at `bithuman_cli/_bin/bithuman`
(per-platform; vendored dylibs sit beside it). This shim is the
`bithuman` console-script entry point — it locates the binary, sets
up the env so the embedded conversation agent finds the wheel's Python
interpreter + bundled `agent.py`, and `execvpe`s into the binary so signal
handling + tty interaction behave exactly as if the user had invoked
the Rust binary directly.

Why a shim at all (vs. exposing the binary directly under
`venv/bin/bithuman`):
    - The Rust binary discovers Python via `BITHUMAN_AGENT_PYTHON` env
      (`BITHUMAN_BRAIN_PYTHON` is honored as a deprecated alias for one
      release). A shim is the cleanest place to point that at
      `sys.executable` (the venv's own python) without depending on PATH
      ordering.
    - It also lets the wheel attach a clear error when the binary
      slot is empty (e.g. a sdist install or an unsupported platform).

Phase B split (2026-05-28): this file used to live at `bithuman/_cli.py`
inside the unified `bithuman` wheel. The CLI was extracted into its
own `bithuman-cli` PyPI wheel; the file is now `bithuman_cli/_entry.py`.
The `BITHUMAN_WHEEL_VERSION` env that the Rust binary surfaces in
`bithuman --version` / `bithuman doctor` now reports the `bithuman-cli`
wheel version (was `bithuman` pre-split).

Apache-2.0; (c) bitHuman.
"""
from __future__ import annotations

import os
import platform
import sys
from pathlib import Path


_PKG_DIR = Path(__file__).resolve().parent
_BIN_DIR = _PKG_DIR / "_bin"


def _load_dotbithuman_config() -> None:
    """Hydrate ``os.environ`` from ``~/.bithuman/config`` so the env we
    hand to ``execvpe`` already carries what ``bithuman init`` saved.

    The Rust binary also loads this file at startup, but doing it here too
    means a mixed install (newer wheel, older Rust binary that pre-dates
    the init wizard) still benefits. Existing env vars win.
    """
    cfg = Path.home() / ".bithuman" / "config"
    try:
        text = cfg.read_text()
    except (FileNotFoundError, OSError):
        return
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        key = key.strip()
        if not key or key in os.environ:
            continue
        os.environ[key] = val.strip().strip('"').strip("'")


def _binary_name() -> str:
    return "bithuman.exe" if platform.system() == "Windows" else "bithuman"


def _binary_path() -> Path:
    return _BIN_DIR / _binary_name()


def _missing_binary_message() -> str:
    triple = f"{platform.system()}-{platform.machine()}".lower()
    return (
        f"bithuman: the bundled CLI binary is missing for this platform "
        f"({triple}).\n"
        f"  Expected at: {_binary_path()}\n"
        "\n"
        "  This usually means you installed an sdist or a wheel built\n"
        "  for a different OS/arch. Reinstall with:\n"
        "      pip install --upgrade --force-reinstall bithuman-cli\n"
        "\n"
        "  If your platform isn't covered by an upstream wheel yet, see:\n"
        "      https://github.com/bithuman-product/homebrew-bithuman/issues\n"
    )


def main() -> int:
    # Pull ~/.bithuman/config into our env BEFORE we copy it for execvpe,
    # so the Rust binary (and any child it spawns) inherits the values
    # bithuman init saved.
    _load_dotbithuman_config()

    binary = _binary_path()
    if not binary.is_file():
        sys.stderr.write(_missing_binary_message())
        return 64  # EX_USAGE

    # Point the Rust binary's agent discovery at this wheel's Python
    # (the venv that pip-installed us) so the embedded `agent.py`
    # picks up all the dependencies (livekit-agents[openai],
    # livekit-plugins-bithuman, aiohttp) declared as required wheel deps.
    # Set BOTH the new (`BITHUMAN_AGENT_*`) and the deprecated
    # (`BITHUMAN_BRAIN_*`) names so an old Rust binary in a mixed install
    # still picks them up; the Rust side prefers the new names.
    env = os.environ.copy()
    env.setdefault("BITHUMAN_AGENT_PYTHON", sys.executable)
    env.setdefault("BITHUMAN_BRAIN_PYTHON", sys.executable)
    agent_script = _PKG_DIR / "agent.py"
    if agent_script.is_file():
        env.setdefault("BITHUMAN_AGENT_SCRIPT", str(agent_script))
        env.setdefault("BITHUMAN_BRAIN_SCRIPT", str(agent_script))

    # Expose the pip wheel version to the Rust binary so `bithuman doctor`
    # and `bithuman --version` can show the PyPI package version
    # alongside the libessence engine. Use importlib.metadata as the
    # source of truth (always matches the actual installed wheel).
    # Phase B split: this is the `bithuman-cli` wheel; the user-visible
    # version shown by `bithuman --version` is the CLI wheel's version
    # (was `bithuman` pre-split — same value when they release in
    # lockstep, but conceptually it's the CLI version now).
    try:
        from importlib.metadata import version as _pkg_version
        env.setdefault("BITHUMAN_WHEEL_VERSION", _pkg_version("bithuman-cli"))
    except Exception:
        pass

    argv = [str(binary), *sys.argv[1:]]
    # execvpe replaces the current process — the Rust binary inherits
    # the tty + signal handlers cleanly. On Windows there's no execve
    # equivalent; we'd subprocess.run() + sys.exit() instead, but Phase
    # 4 ships macOS arm64 + Linux first, so we punt on that branch.
    os.execvpe(str(binary), argv, env)
    # Unreachable; execvpe never returns on success.
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
